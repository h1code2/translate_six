# @Time    : 2019/10/16 0016 上午 8:46
# @Author  : h.user
# @Email   : h.user.com
# @File    : __init__.py
# @Software: PyCharm

from __future__ import absolute_import
from .translate import GoogleTranslate

name = "translate_six"
