## translate_six
A simple package based on the google translation interface

**example:**
```python
from translate import GoogleTranslate

Translate = GoogleTranslate()

result = Translate.start_translate("hello")